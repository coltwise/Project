import express from 'express';
import moment from 'moment-timezone'

const configViewEngine = (app) => {
    app.use(express.static("./src/public"));
    app.set('view engine', "ejs");
    app.set('views', "./src/views");

    //set the timezone
    moment.tz.setDefault('Etc/GMT+5:30')
}

export default configViewEngine;